-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2019 at 05:26 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db3`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`) VALUES
('Aqsa', '0311');

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `id` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `C_ID` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`id`, `title`, `C_ID`) VALUES
('2', 'make 5 unction', '1'),
('100', 'console use', '3'),
('4', 'Markshceet on Excel', '1'),
('5', 'youtube app layout ', '10'),
('6', 'slidder using array ', '6'),
('7', 'change privileges in oracle', '8');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `C_ID` int(10) NOT NULL,
  `C_NAME` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`C_ID`, `C_NAME`) VALUES
(1, 'JAVA'),
(2, 'C++'),
(3, 'ASP.NET'),
(4, 'perl'),
(6, 'php'),
(7, 'Andriod'),
(8, 'DMBS'),
(9, 'Ms Office'),
(10, 'Graphic Designing'),
(1, 'JAVA');

-- --------------------------------------------------------

--
-- Table structure for table `login_std`
--

CREATE TABLE `login_std` (
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_std`
--

INSERT INTO `login_std` (`name`, `password`) VALUES
('aisha', '33');

-- --------------------------------------------------------

--
-- Table structure for table `login_tech`
--

CREATE TABLE `login_tech` (
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_tech`
--

INSERT INTO `login_tech` (`name`, `password`) VALUES
('aamir', '123');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `C_ID` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`name`, `email`, `password`, `C_ID`) VALUES
('Aqsa', 'aqsa.shaikh2254@gmail.com', 'f16cs17', '2'),
('aamir', 'aqsa.shaikh2254@gmail.com', '0311', '6'),
('Aqsa', 'aqsa.shaikh2245@gmail.com', '8h9k', 'Ms Office'),
('misbah', 'misbah.shaik1771@gmail.com', 'jan24', 'Graphic Designing'),
('Aqsa', 'aqsa.shaikh2245@gmail.com', '8h9k', 'Ms Office'),
('aisha', 'aisha.khan2287@gmail.comm', 'f16cs33', 'JAVA'),
('mahanoor', 'mahnoor.khan34435@gmail.com', '', 'JAVA'),
('mahanoor', 'mahnoor.khan34435@gmail.com', '19feb', 'Ms Office'),
('mahanoor', 'mahnoor.khan34435@gmail.com', '19feb', 'Ms Office'),
('mahanoor', 'mahnoor.khan34435@gmail.com', '19feb', 'Ms Office'),
('mahanoor', 'mahnoor.khan34435@gmail.com', '', 'JAVA'),
('areehsa', 'aresha.shaikh2901@gmail.com', '17nov', 'DMBS'),
('waqar', 'mahnoor.khan34435@gmail.com', '26march', 'Andriod');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `s_id` int(10) NOT NULL,
  `sname` varchar(40) NOT NULL,
  `C_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_id`, `sname`, `C_ID`) VALUES
(5, 'aqsa', 4),
(18, 'Aisha', 9),
(29, 'Ruqaya', 6),
(55, 'kanchan', 1),
(25, 'anum', 7),
(16, 'hafsa', 2),
(59, 'nimra', 10),
(27, 'munnaza', 1),
(151, 'taha', 7),
(30, 'alisha', 1),
(3, 'armish', 3);

-- --------------------------------------------------------

--
-- Table structure for table `submit`
--

CREATE TABLE `submit` (
  `id` int(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `C_ID` int(40) NOT NULL,
  `s_id` varchar(40) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `value` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submit`
--

INSERT INTO `submit` (`id`, `title`, `C_ID`, `s_id`, `sname`, `value`) VALUES
(1, 'constructer', 1, '17', 'aqsa', 'this is my assignmet plzzzz sumit it..'),
(2, 'make 5  function', 6, '17', 'Aqsa', 'Web engineering is multidisciplinary and encompasses contributions from diverse areas: systems analysis and design, software engineering, hypermedia/hypertext engineering,  user interface, information engineering, testing, modelling and simulation, project management, and graphic design and presentation. Web engineering is neither a clone nor a subset of software engineering, although both involve programming and software development. While Web Engineering uses software engineering principles, it encompasses new approaches, methodologies, tools, techniques, and guidelines to meet the unique requirements of Web-based applications.\r\n\r\nWeb application \r\n\r\nA Web application (Web app) is an application program  that is stored on a  server and delivered over the Internet through a browser interface. web applications use web documents written in a standard format such as HTML and JavaScript, which are supported by a variety of web browsers.Googleâ€™s search engine is also web app, Web applications include online forms, shopping carts, word processors, spreadsheets, video and photo editing, file conversion, file scanning, and email programs such as Gmail,\r\n'),
(2, 'constructer', 1, '21', 'seher', 'here it not busy...');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `t_id` int(10) NOT NULL,
  `tname` varchar(40) NOT NULL,
  `C_ID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`t_id`, `tname`, `C_ID`) VALUES
(201, 'arbab', 1),
(204, 'Ali asghar ', 7),
(205, 'Mahaveer Rathi', 6),
(206, 'sanam ', 8),
(207, 'Mehak Memon', 10),
(208, 'Aisha soomro', 9),
(210, 'KB Soomro', 4),
(203, 'Ahsan Ansari', 3),
(209, 'sara mahesar', 4),
(209, 'sara mahesar', 4),
(210, 'sameer ali', 6);

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `tp_id` int(10) NOT NULL,
  `tp_name` varchar(40) NOT NULL,
  `C_ID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`tp_id`, `tp_name`, `C_ID`) VALUES
(1, 'control sturcture in php', 4),
(2, 'Relative Layout', 7),
(3, 'data types  in java', 1),
(4, 'functionsk', 1),
(5, 'tables in word', 9),
(6, 'logo design', 10),
(7, 'inner loop  with diffent pattern', 2),
(9, 'Method Overriding ', 1),
(13, 'switch statment', 2),
(9, 'view in dbms', 10),
(10, 'MODLATION', 4);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
